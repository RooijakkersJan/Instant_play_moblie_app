package com.Adv.developer.instantmobile;

public class KbdPlaylist {
    private boolean selected;
    String playlistid="";
    String playlistname="";



    public String getplaylistid()
    {
        return playlistid;
    }

    public void setplaylistid(String id) {
        playlistid=id;
    }

    public String getPlaylistname()
    {
        return playlistname;
    }

    public void setPlaylistname(String name) {
        playlistname=name;
    }


}
