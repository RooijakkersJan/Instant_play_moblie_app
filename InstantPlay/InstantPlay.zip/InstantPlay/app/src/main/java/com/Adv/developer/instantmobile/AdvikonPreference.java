package com.Adv.developer.instantmobile;

public class AdvikonPreference {
    public static final String FCMId = "fcmid";
    public static final String UserId = "userid";
    public static final String dfClientId = "dfclientid";
    public static final String Clientname= "clientname";
    public static final String chkAdmin = "true";


}
