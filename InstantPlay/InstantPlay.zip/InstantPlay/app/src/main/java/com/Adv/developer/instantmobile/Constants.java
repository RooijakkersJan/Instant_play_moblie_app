package com.Adv.developer.instantmobile;

public class Constants {

    public static final String SERVER = "https://api.advikon.com/api/";
   // public static final String SERVER = "http://api.nusign.eu/api/";

    public static final String GetPlayerToken = SERVER + "FillTokenInfo";//DeviceId
    public static final int GetPlayerToken_TAG = 1;


    public static final String PlaylistTitles= SERVER + "GetInstantPlaySpecialPlaylistsTitles";//DeviceId,TokenNo,UserName
    public static final int Playlist_Titles_TAG= 3;


    public static final String CHECKCustomerLogin = SERVER + "CustomerLogin";//DeviceId,TokenNo,UserName
    public static final int CHECK_CustomerLogin_TAG= 5;

    public static final String CHECKInstantPlay = SERVER + "InstantPlay";//DeviceId,TokenNo,UserName
    public static final int CHECK_InstantPlay_TAG= 6;


    public static final String GetkbdPlaylist = SERVER + "GetSplPlaylistVideo";//DeviceId,TokenNo,UserName
    public static final int CHECK_KBdPlaylist_TAG= 7;

    public static final String GetkbdContents = SERVER + "GetSplPlaylistTitlesLive";//DeviceId,TokenNo,UserName
    public static final int GetkbdContents_TAG= 8;

    public static final String GetkbdPlayerToken = SERVER + "FillTokenInfo";//DeviceId
    public static final int GetkbdPlayerToken_TAG = 9;




}
