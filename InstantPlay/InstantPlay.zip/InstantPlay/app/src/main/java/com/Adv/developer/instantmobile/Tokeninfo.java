package com.Adv.developer.instantmobile;

public class Tokeninfo {
    private boolean selected;
    String tokenid="";
    String tokeninfo="";

    public String getToken()
    {
        return tokenid;
    }

    public void setToken(String id) {
        tokenid=id;
    }

    public String getTokeninfo()
    {
        return tokeninfo;
    }

    public void setTokeninfo(String id) {
        tokeninfo=id;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
