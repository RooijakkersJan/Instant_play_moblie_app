package com.Adv.developer.instantmobile;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.github.rahatarmanahmed.cpv.CircularProgressView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;


public class HomeActivity extends AppCompatActivity implements OkHttpUtil.OkHttpResponse, View.OnClickListener,CustomSpinner.OnSpinnerEventsListener,CompoundButton.OnCheckedChangeListener {
    public CustomSpinner spinnerfrPlayertoken;
    public Spinner spinnerfrPlaylist,spinnerfrkbdToken;
    public Dialog pickerDialogpopup;
    public MyAdapter myAdapter;
    public Dialog pickerDialog;
    public RadioButton radioButtonInstant,radioButtonKbd;
    RelativeLayout spinlayout;
    public TextView tv, tv1,tv3;
    public ImageView tv2;
    private String selplaylistid="";
    private String selkbtoken="";
    public SongAdapter songAdapter;
    public ListView lvSongs;
    Typeface fontBold;
    CircularProgressView pv;

    public ArrayList<String> arrspin = new ArrayList<String>();
    public ArrayList<String>  arrtokenkbd= new ArrayList<String>();

    public HashMap<String, String> arrkeybdplaylist = new HashMap<>();

    public ArrayList<Tokeninfo> arrtoken = new ArrayList<>();
    public ArrayList<Songs> arrsongs = new ArrayList<Songs>();
    public ArrayList<String> arrtokentosend = new ArrayList<String>();
    public ArrayList<Tokeninfo> arrtokentodisp = new ArrayList<Tokeninfo>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        spinlayout = (RelativeLayout) findViewById(R.id.spinnerlay);
        pv = (CircularProgressView) findViewById(R.id.progress_view);
        spinnerfrPlayertoken = (CustomSpinner) findViewById(R.id.dropdowntokenlist);
        spinnerfrPlaylist= (Spinner) findViewById(R.id.dropdownplaylist);
        spinnerfrkbdToken=(Spinner) findViewById(R.id.dropdownkbdtoken);
        fontBold = Typeface.createFromAsset(HomeActivity.this.getAssets(), this.getString(R.string.century_font_bold));
        tv = (TextView) findViewById(R.id.txtplayer);
        tv3 = (TextView) findViewById(R.id.txtClientname);
        tv1 = (TextView) findViewById(R.id.txtplaylist);
        tv2 = (ImageView) findViewById(R.id.txtlogout);
        radioButtonInstant =(RadioButton) findViewById(R.id.radioInstant);
        radioButtonKbd =(RadioButton) findViewById(R.id.radioKbd);
        tv.setTypeface(fontBold);
        tv1.setTypeface(fontBold);
        lvSongs = (ListView) findViewById(R.id.lvSongs);
        String clientname= SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.Clientname);
        tv3.setText(clientname);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        tv2.setOnClickListener(this);
        radioButtonKbd.setOnCheckedChangeListener(this);
        radioButtonInstant.setOnCheckedChangeListener(this);
        getTokenInfo();

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.txtlogout: {
                popuplogout();
            }
            break;

        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            if (buttonView.getId() == R.id.radioInstant) {
                radioButtonKbd.setChecked(false);
                lvSongs.setVisibility(View.INVISIBLE);
                spinnerfrPlaylist.setVisibility(View.GONE);
                spinnerfrkbdToken.setVisibility(View.GONE);
                spinnerfrPlayertoken.setVisibility(View.VISIBLE);
                getTokenInfo();

            }
            if (buttonView.getId() == R.id.radioKbd) {
                radioButtonInstant.setChecked(false);
                if(radioButtonKbd.isChecked())
                {
                    getkbdTokeninfo();
                    //getplaylistfrKeybrd();
                    spinnerfrPlayertoken.setVisibility(View.INVISIBLE);
                    spinnerfrkbdToken.setVisibility(View.VISIBLE);
                    lvSongs.setVisibility(View.INVISIBLE);

                }
            }
        }
    }

    public void getkbdTokeninfo()
    {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("clientId", SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.dfClientId));
            jsonObject.put("DBType", "Advikon");
            jsonObject.put("IsActiveTokens", "1");
            jsonObject.put("UserId", SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.UserId));
            new OkHttpUtil(HomeActivity.this, Constants.GetkbdPlayerToken, jsonObject.toString(),
                    HomeActivity.this, false,
                    Constants.GetkbdPlayerToken_TAG).
                    callRequest();
        } catch (Exception e) {
            e.getCause();
        }
    }


    public void getplaylistfrKeybrd()
    {
        try {
            JSONObject jsonObject = new JSONObject();

            JSONArray array = new JSONArray();

            jsonObject.put("TokenId",Integer.parseInt(selkbtoken));
            jsonObject.put("DfClientId", SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.dfClientId));
            jsonObject.put("WeekNo",getCurrentDayNumber());

            new OkHttpUtil(HomeActivity.this, Constants.GetkbdPlaylist, jsonObject.toString(),
                    HomeActivity.this, false,
                    Constants.CHECK_KBdPlaylist_TAG).
                    callRequest();
        } catch (Exception e) {
            e.getCause();
        }
    }

    public int getCurrentDayNumber(){

        SimpleDateFormat sdf = new SimpleDateFormat("EEEE", Locale.US);
        Date d = new Date();
        String dayOfTheWeek = sdf.format(d);
        return getDayNumber(dayOfTheWeek);
    }

    public static int getDayNumber(String day){
        int dayNumber = 0;
        if (day.equals("Monday")){
            dayNumber = 1;
        }else if (day.equals("Tuesday")){
            dayNumber = 2;
        }else if (day.equals("Wednesday")){
            dayNumber = 3;
        }else if (day.equals("Thursday")){
            dayNumber = 4;
        }else if (day.equals("Friday")){
            dayNumber = 5;
        }else if (day.equals("Saturday")){
            dayNumber = 6;
        }else if (day.equals("Sunday")){
            dayNumber = 7;
        }

        return dayNumber;
    }
    public void logout() {
        MySQLiteHelper sb = new MySQLiteHelper(HomeActivity.this);
        sb.deletecredential();
        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public void popuplogout() {
        pickerDialogpopup = new Dialog(HomeActivity.this);
        pickerDialogpopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
        pickerDialogpopup.setContentView(R.layout.logoutpopup);
        pickerDialogpopup.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView txtcancel = (TextView) pickerDialogpopup.findViewById(R.id.btnNo);
        TextView txtcontinue = (TextView) pickerDialogpopup.findViewById(R.id.btnYes);
        txtcancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickerDialogpopup.dismiss();
            }
        });
        txtcontinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
        pickerDialogpopup.show();


    }


    @Override
    public void onResponse(String response, int tag) {
        if (response == null || response.equals("") || response.length() < 1) {
            // Utilities.showToast(HomeActivity.this, "Empty response for player statuses");
            return;
        } else {
            switch (tag) {

                case Constants.GetPlayerToken_TAG: {
                    TokenForPlayer(response);
                }
                break;

                case Constants.Playlist_Titles_TAG: {
                    PlaylistSong(response);
                }
                break;

                case Constants.CHECK_KBdPlaylist_TAG: {
                    spinnerfrPlaylist.setVisibility(View.GONE);
                    kbdplaylistresponse(response);
                }
                break;

                case Constants.GetkbdContents_TAG: {
                    PlaylistSong(response);

                }
                break;

                case Constants.GetkbdPlayerToken_TAG: {
                    fillkbdtoken(response);
                }
                break;

                case Constants.CHECK_InstantPlay_TAG: {
                    Instantsong(response);
                }
                break;
            }
        }
    }

    @Override
    public void onError(Exception e, int tag) {

        Toast.makeText(HomeActivity.this, e.toString(), Toast.LENGTH_LONG).show();

    }

    private void fillkbdtoken(String response)
    {
        try {
            arrtokenkbd.clear();
            JSONArray jsonArray = new JSONArray(response);
            arrtokenkbd.add("--Select Token--");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String tokenid = jsonObject.getString("tokenid");
               // String tokeninfo = jsonObject.getString("city");
                arrtokenkbd.add(tokenid);
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(HomeActivity.this, android.R.layout.simple_spinner_item, arrtokenkbd);
                    arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerfrkbdToken.setAdapter(arrayAdapter);
                    spinnerfrkbdToken.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view,
                                                   int position, long id) {

                            Object item = adapterView.getItemAtPosition(position);
                            if((item!=null) &&(!item.equals("--Select Token--"))) {
                                selkbtoken = item.toString();
                                getplaylistfrKeybrd();
                            }
                            else
                            {
                                if(item.equals("--Select Token--"))
                                {
                                    selkbtoken=item.toString();

                                }
                                lvSongs.setVisibility(View.INVISIBLE);
                                spinnerfrPlaylist.setSelection(0);
                            }
                        }
                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                            // TODO Auto-generated method stub
                        }
                    });
                }
            });
        }catch (Exception e)
        {
            e.getCause();
        }
    }
    private void kbdplaylistresponse(String response)
    {

        try {
            arrkeybdplaylist.clear();
            arrspin.clear();
            selplaylistid="";
            if (response!=null) {
              //  KbdPlaylist modal1=new KbdPlaylist();
               // modal1.setPlaylistname("--Select Playlist--");
              //  modal1.setplaylistid("00");
              //  arrspin.add(modal1.getPlaylistname());
                JSONArray jsonArray = new JSONArray(response);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    String playlistname = jsonObj.getString("splPlaylistName");
                    String playlistid = jsonObj.getString("splPlaylistId");
                    KbdPlaylist modal=new KbdPlaylist();
                    modal.setPlaylistname(playlistname);
                    modal.setplaylistid(playlistid);
                    arrspin.add(modal.getplaylistid());
                    arrkeybdplaylist.put(playlistname,playlistid);
                }

                int p=arrspin.size();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(HomeActivity.this, android.R.layout.simple_spinner_item, arrspin);
                        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerfrPlaylist.setAdapter(arrayAdapter);
                        selplaylistid=arrspin.get(0);
                        getTitlesKbdPlaylist();

                      /*  spinnerfrPlaylist.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view,
                                                       int position, long id) {
                                Object item = adapterView.getItemAtPosition(position);
                                if(!selkbtoken.equals("--Select Token--")) {
                                    if (item != null) {
                                        selplaylistid = arrkeybdplaylist.get(item);

                                        if (arrtokenkbd.size() > 0) {
                                            getTitlesKbdPlaylist();
                                        }
                                    } else {
                                        lvSongs.setVisibility(View.INVISIBLE);
                                    }
                                }

                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {
                                // TODO Auto-generated method stub
                            }
                        });*/
                    }
                });
            }
        } catch (Exception e) {
            e.getCause();
        }



    }



    private void getPlaylistTitles() {
        try {
            spinlayout.setVisibility(View.VISIBLE);
            pv.setVisibility(View.VISIBLE);
            pv.startAnimation();
            lvSongs.setVisibility(View.INVISIBLE);
            JSONObject jsonObject = new JSONObject();
            JSONArray array = new JSONArray();

            for (int i = 0; i < arrtokentosend.size(); i++) {
                array.put(Integer.parseInt(arrtokentosend.get(i)));
            }

            jsonObject.put("Tokenid",array);


            new OkHttpUtil(HomeActivity.this, Constants.PlaylistTitles, jsonObject.toString(),
                    HomeActivity.this, false,
                    Constants.Playlist_Titles_TAG).
                    callRequest();
        } catch (Exception e) {
            e.getCause();
        }
    }

    public void Instantsong(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            String res = jsonObject.getString("Response");
            if (res.equals("1")) {
                Toast.makeText(HomeActivity.this, "Request Send", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(HomeActivity.this, "Request Failed ", Toast.LENGTH_LONG).show();

            }
        } catch (Exception e) {
            e.getCause().toString();
        }
    }

    private void getTokenInfo() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("clientId", SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.dfClientId));
            jsonObject.put("DBType", "Advikon");
            jsonObject.put("IsActiveTokens", "1");
            jsonObject.put("UserId", SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.UserId));
            new OkHttpUtil(HomeActivity.this, Constants.GetPlayerToken, jsonObject.toString(),
                    HomeActivity.this, false,
                    Constants.GetPlayerToken_TAG).
                    callRequest();
        } catch (Exception e) {
            e.getCause();
        }
    }




    public void previewsong(int position) {
        pickerDialog = new Dialog(HomeActivity.this);
        pickerDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        pickerDialog.setContentView(R.layout.custom_pop_preview_song);
        pickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        pickerDialog.setTitle("Previewsong");
      /*  com.devbrackets.android.exomedia.ui.widget.VideoView videoView = (com.devbrackets.android.exomedia.ui.widget.VideoView) pickerDialog.findViewById(R.id.video_view);
        String url = arrsongs.get(position).getSongPath();
        videoView.setVideoURI(Uri.parse(url));
        videoView.setScaleType(ScaleType.FIT_XY);
        videoView.start();
        videoView.setBackgroundColor(getResources().getColor(R.color.Black));
        videoView.setOnCompletionListener(new OnCompletionListener() {
            @Override
            public void onCompletion() {
                pickerDialog.dismiss();
            }

        });*/
        pickerDialog.show();


    }


    public void instantplaysong(int position,int checked) {
        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("albumid", "0");
            jsonObject.put("artistid", arrsongs.get(position).getArtist_ID());
            jsonObject.put("artistname", arrsongs.get(position).getAr_Name());
            if(radioButtonKbd.isChecked())
            {
                jsonObject.put("id",String.valueOf(arrsongs.get(position).getSerialNo()));
            }
            else {
                jsonObject.put("id", arrsongs.get(position).getTitle_Id());
            }
            jsonObject.put("mediatype", arrsongs.get(position).getMediatype());

            jsonObject.put("title", arrsongs.get(position).getTitle());
            jsonObject.put("Repeat", checked);

            JSONArray jsonarray = new JSONArray();
            if(radioButtonKbd.isChecked())
            {
                    jsonarray.put(Integer.parseInt(selkbtoken));
            }

            else
            {

                for (int i = 0; i < arrtokentosend.size(); i++) {
                    jsonarray.put(Integer.parseInt(arrtokentosend.get(i)));
                }
            }

            jsonObject.put("tid", jsonarray);

            new OkHttpUtil(HomeActivity.this, Constants.CHECKInstantPlay, jsonObject.toString(),
                    HomeActivity.this, false,
                    Constants.CHECK_InstantPlay_TAG).
                    callRequest();
        } catch (Exception e) {
            e.getCause();
        }
    }

   private void getTitlesKbdPlaylist()
   {
       try {
           spinlayout.setVisibility(View.VISIBLE);
           pv.setVisibility(View.VISIBLE);
           pv.startAnimation();
           lvSongs.setVisibility(View.INVISIBLE);
           JSONObject jsonObject = new JSONObject();

           jsonObject.put("splPlaylistId",Integer.parseInt(selplaylistid));

           new OkHttpUtil(HomeActivity.this, Constants.GetkbdContents, jsonObject.toString(),
                   HomeActivity.this, false,
                   Constants.GetkbdContents_TAG).
                   callRequest();
       } catch (Exception e) {
           e.getCause();
       }
   }




    private void PlaylistSong(String response) {

        try {
            if(response.equals("[]"))
            {
                Toast.makeText(HomeActivity.this,"No songs",Toast.LENGTH_LONG).show();
                spinlayout.setVisibility(View.GONE);
                pv.setVisibility(View.INVISIBLE);
                pv.stopAnimation();
                return;
            }
            arrsongs.clear();
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String albumid = jsonObject.getString("AlbumID");
                String artistid = jsonObject.getString("ArtistID");
                String artistname = jsonObject.getString("arName");
                String album = jsonObject.getString("alName");
                String titleid = jsonObject.getString("titleId");
                Long srno=jsonObject.getLong("srno");
                String mtype= jsonObject.getString("mediatype");
                String length = jsonObject.getString("tTime");
                String splid = jsonObject.getString("splPlaylistId");
                String titlename = jsonObject.getString("Title");
                String titleurl = jsonObject.getString("TitleUrl");
                Songs model = new Songs();
                model.setAl_Name(album);
                model.setgMediatype(mtype);
                model.setAlbum_ID(albumid);
                model.setSpl_PlaylistId(splid);
                model.setArtist_ID(artistid);
                model.setAr_Name(artistname);
                model.setTitle(titlename);
                model.setSerialNo(srno);
                model.setTitle_Id(titleid);
                model.setT_Time(length);
                model.setSongPath(titleurl);
                arrsongs.add(model);
            }
            arrsongs.size();
            spinlayout.setVisibility(View.GONE);
            pv.setVisibility(View.INVISIBLE);
            pv.stopAnimation();
            songAdapter = new SongAdapter(HomeActivity.this, arrsongs);
            lvSongs.setAdapter(songAdapter);
            lvSongs.setVisibility(View.VISIBLE);

        } catch (Exception e) {
            e.getCause();
        }

    }


    private void TokenForPlayer(String response) {
        try {
            arrtoken.clear();
            JSONArray jsonArray = new JSONArray(response);
            String chkadmin = SharedPreferenceUtil.getStringPreference(HomeActivity.this, AdvikonPreference.chkAdmin);
            Tokeninfo model1 = new Tokeninfo();
            Tokeninfo model2 = new Tokeninfo();
            model1.setToken(" ");
            model1.setTokeninfo(" ");
            arrtoken.add(model1);
            if (chkadmin.equals("true")) {
                model2.setToken("00000");
                model2.setTokeninfo("All Locations");
                arrtoken.add(model2);
            }
            for (int i = 0; i < jsonArray.length(); i++) {
                Tokeninfo model = new Tokeninfo();
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String tokenid = jsonObject.getString("tokenid");
                String tokeninfo = jsonObject.getString("city");

                model.setToken(tokenid);
                model.setTokeninfo(tokeninfo);
                arrtoken.add(model);
            }
            myAdapter = new MyAdapter(HomeActivity.this, 0,
                    arrtoken);
            spinnerfrPlayertoken.setAdapter(myAdapter);
            spinnerfrPlayertoken.setSpinnerEventsListener(this);

        } catch (Exception e) {
            e.getCause();
        }
    }


    @Override
    public void onSpinnerOpened(Spinner spin) {
    }


    @Override
    public void onSpinnerClosed(Spinner spin) {
        arrtokentosend.clear();
        arrtokentodisp.clear();
        for (int i = 0; i < arrtoken.size(); i++) {
            if (arrtoken.get(i).isSelected()) {
                if (arrtoken.get(i).getTokeninfo().equals(" ") || arrtoken.get(i).getTokeninfo().equals("All Locations")) {
                    // arrtoken.remove(i);
                } else {
                    arrtokentosend.add(arrtoken.get(i).tokenid);
                    arrtokentodisp.add(arrtoken.get(i));
                }
            }

        }
        if (arrtokentodisp.size() > 0) {
            myAdapter.getPosition(arrtokentodisp.get(0));
            spinnerfrPlayertoken.setSelection(myAdapter.getPosition(arrtokentodisp.get(0)));
            lvSongs.setVisibility(View.INVISIBLE);
        } else {
            spinnerfrPlayertoken.setSelection(0);
            lvSongs.setVisibility(View.INVISIBLE);
        }



        if (arrtokentosend.size() > 0 && radioButtonInstant.isChecked() )
        {
           getPlaylistTitles();
        }
        else
        {
            lvSongs.setVisibility(View.INVISIBLE);
        }

    }


}
